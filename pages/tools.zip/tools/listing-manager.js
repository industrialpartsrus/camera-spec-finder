import UnifiedListingManager from '../../components/UnifiedListingManager';

export default function UnifiedListingManagerPage() {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6' }}>
      <UnifiedListingManager />
    </div>
  );
}
