import CategoryHealthCheck from '../../components/CategoryHealthCheck';

export default function CategoryHealthCheckPage() {
  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6' }}>
      <CategoryHealthCheck />
    </div>
  );
}
